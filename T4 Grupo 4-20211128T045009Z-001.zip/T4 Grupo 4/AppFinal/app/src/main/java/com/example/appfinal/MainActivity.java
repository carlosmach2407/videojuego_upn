package com.example.appfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText v_correo,v_contraseña;
    Button v_ingresar,v_registrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        v_correo=findViewById(R.id.correo);
        v_contraseña=findViewById(R.id.contraseña);
        v_ingresar=findViewById(R.id.buttoningresar);
        v_registrar=findViewById(R.id.buttonregistrar);

        v_registrar.setOnClickListener(this);
        v_ingresar.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttoningresar:validarSesion(v_correo.getText().toString(),v_contraseña.getText().toString());
            break;

            case R.id.buttonregistrar: registar();
        }
    }

    private void validarSesion(String correo,String contraseña){
        if(correo.isEmpty()||contraseña.isEmpty()){
            Toast.makeText(this,"rellene los campos",Toast.LENGTH_LONG).show();
        }
        else{
            Intent iPrincipal =new Intent (this,principal.class);
            startActivity(iPrincipal);
            finish();
        }
    }

    private void registar(){
        Intent iPrincipal =new Intent(this,RegistroUserPr.class);
        startActivity(iPrincipal);
        finish();
    }
}