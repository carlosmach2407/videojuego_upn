package com.example.appfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class RegistroUserPr extends AppCompatActivity implements View.OnClickListener {

    Button v_profesor,v_estudiante;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_user_pr);

        v_estudiante=findViewById(R.id.buttonestudiante);
        v_profesor=findViewById(R.id.buttonprofe);

        v_estudiante.setOnClickListener(this);
        v_profesor.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.buttonestudiante: regestudiante();
                    break;
            case R.id.buttonprofe: regprofe();
                  break;
        }
    }

    private void regestudiante(){
        Intent iPrincipal = new Intent(this,RegistroEstudiante.class);
        startActivity(iPrincipal);
        finish();
    }

    private  void regprofe(){
        Intent iPrincipal = new Intent(this,RegistroProfesor.class);
        startActivity(iPrincipal);
        finish();
    }
}