package com.example.appfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RegistroProfesor extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_profesor);
    }
}